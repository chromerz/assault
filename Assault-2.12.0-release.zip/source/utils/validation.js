export function utf8Size(text) {
  let bytes = 0;
  for (const character of text) { const point = character.codePointAt(0); bytes += point <= 0x7f ? 1 : point <= 0x7ff ? 2 : point <= 0xffff ? 3 : 4; }
  return bytes;
}
export const LIMITS = { source: 65536, state: 32768, archive: 4 * 1024 * 1024, addons: 32 };
export function ensure(condition, message) { if (!condition) throw new Error(message); }
export function key(value) {
  ensure(typeof value === 'string' && /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(value) && !['constructor', 'prototype', '__proto__'].includes(value), 'Invalid property name.');
  return value;
}
export function jsonCopy(value, limit = LIMITS.state) {
  // Bound the expanded graph BEFORE JSON.stringify. Repeated references created
  // by interpreted const locals can otherwise expand exponentially during encoding.
  let size = 0, nodes = 0;
  const ancestors = new Set();
  function charge(amount) { size += amount; ensure(size <= limit, 'Data exceeds the storage limit.'); }
  function walk(item, depth) {
    ensure(depth < 24 && ++nodes <= Math.min(100000, limit / 2), 'Data is nested too deeply or has too many values.');
    if (item === null || ['string', 'number', 'boolean'].includes(typeof item)) {
      ensure(typeof item !== 'number' || Number.isFinite(item), 'Numbers must be finite.');
      if (typeof item === 'string') ensure(item.length * 2 <= limit, 'Data exceeds the storage limit.');
      charge(JSON.stringify(item).length * 2);
      return;
    }
    ensure(item && typeof item === 'object' && !ancestors.has(item), 'Only acyclic JSON data is supported.');
    ancestors.add(item); charge(4);
    for (const name of Object.keys(item)) {
      ensure(!['__proto__', 'prototype', 'constructor'].includes(name), 'Unsafe property name.');
      if (!Array.isArray(item)) charge(JSON.stringify(name).length * 2 + 2);
      charge(2); walk(item[name], depth + 1);
    }
    ancestors.delete(item);
  }
  walk(value, 0);
  return JSON.parse(JSON.stringify(value));
}
export function message(error) { return error instanceof Error ? error.message.slice(0, 240) : 'The operation failed. Please retry.'; }
export function settingsValues(schema, values = {}) {
  ensure(values && typeof values === 'object' && !Array.isArray(values), 'Invalid settings.');
  const result = Object.create(null);
  for (const [name, field] of Object.entries(schema)) {
    const value = Object.prototype.hasOwnProperty.call(values, name) ? values[name] : field.default;
    ensure(typeof value === field.type && (field.type !== 'string' || value.length <= 512) &&
      (field.type !== 'number' || Number.isFinite(value) && value >= field.min && value <= field.max), `Invalid setting: ${field.label}`);
    result[name] = value;
  }
  return result;
}
