import { parse } from 'acorn';
import { ensure, key, jsonCopy, LIMITS, utf8Size } from '../utils/validation.js';

const hooks = new Set(['onStart', 'onStop', 'onSettingsChanged']);
const calls = new Set(['getSetting', 'getState', 'setState', 'notify']);
const operators = new Set(['+', '-', '*', '/', '%', '===', '!==', '<', '<=', '>', '>=']);
// Untrusted AST nodes are interpreted as data. No eval, Function, host objects,
// prototype lookup, imports, callbacks, loops or user-defined calls cross this boundary.
function validate(node, depth = 0, hook = false) {
  ensure(depth < 48, 'JavaScript is nested too deeply.');
  const visit = child => validate(child, depth + 1, hook);
  switch (node.type) {
    case 'Literal': ensure(node.regex === undefined && node.bigint === undefined, 'Regular expressions and BigInt are unsupported.'); break;
    case 'Identifier': key(node.name); ensure(node.name !== 'api', 'API objects cannot be stored or returned.'); break;
    case 'ObjectExpression':
      ensure(node.properties.length <= 128, 'Too many object properties.');
      for (const property of node.properties) {
        ensure(property.type === 'Property' && !property.computed && property.kind === 'init', 'Only plain object properties are supported.');
        const name = key(property.key.name ?? property.key.value);
        if (depth === 0 && hooks.has(name)) ensure(['FunctionExpression', 'ArrowFunctionExpression'].includes(property.value.type), 'Lifecycle hooks must be functions.');
        if (property.value.type === 'FunctionExpression' || property.value.type === 'ArrowFunctionExpression') {
          ensure(!hook && depth === 0 && hooks.has(name), 'Functions are only allowed as lifecycle hooks.');
          const fn = property.value;
          ensure(!fn.async && !fn.generator && fn.params.length === 1 && fn.params[0].type === 'Identifier' && fn.params[0].name === 'api', 'Lifecycle hooks take one parameter named api.');
          validate(fn.body, depth + 1, true);
        } else visit(property.value);
      }
      break;
    case 'ArrayExpression': ensure(node.elements.length <= 128, 'Array is too large.'); node.elements.forEach(n => { ensure(n, 'Array holes are unsupported.'); visit(n); }); break;
    case 'CallExpression':
      ensure(hook && !node.optional && node.callee.type === 'MemberExpression' && !node.callee.computed && node.callee.object.type === 'Identifier' && node.callee.object.name === 'api' && calls.has(node.callee.property.name), 'Only whitelisted api calls are allowed. Node.js, Discord internals and native modules are unavailable.');
      ensure(node.arguments.length <= 2, 'Too many API arguments.'); node.arguments.forEach(visit); break;
    case 'BinaryExpression': ensure(operators.has(node.operator), 'Unsupported operator.'); visit(node.left); visit(node.right); break;
    case 'LogicalExpression': ensure(['&&', '||', '??'].includes(node.operator), 'Unsupported operator.'); visit(node.left); visit(node.right); break;
    case 'UnaryExpression': ensure(['!', '+', '-'].includes(node.operator), 'Unsupported operator.'); visit(node.argument); break;
    case 'ConditionalExpression': visit(node.test); visit(node.consequent); visit(node.alternate); break;
    case 'BlockStatement': node.body.forEach(visit); break;
    case 'ExpressionStatement': ensure(hook, 'Expressions require a lifecycle hook.'); visit(node.expression); break;
    case 'VariableDeclaration':
      ensure(hook && node.kind === 'const', 'Only const local declarations are supported.');
      for (const d of node.declarations) { ensure(d.id.type === 'Identifier' && d.id.name !== 'api' && d.init, 'Invalid local variable.'); key(d.id.name); visit(d.init); }
      break;
    case 'IfStatement': visit(node.test); visit(node.consequent); if (node.alternate) visit(node.alternate); break;
    case 'ReturnStatement': if (node.argument) visit(node.argument); break;
    default: throw new Error(`Unsupported JavaScript syntax: ${node.type}. Use the documented sandbox API.`);
  }
}
function evaluate(root, api, hook = false) {
  let budget = 5000;
  const locals = new Map();
  const returned = Symbol('return');
  function run(n) {
    ensure(--budget >= 0, 'Plugin exceeded its execution budget.');
    let left, right;
    switch (n.type) {
      case 'Literal': return n.value;
      case 'Identifier': ensure(locals.has(n.name), `Unknown variable: ${n.name}`); return locals.get(n.name);
      case 'ObjectExpression': {
        const value = Object.create(null);
        for (const p of n.properties) {
          const name = p.key.name ?? p.key.value;
          if (!['FunctionExpression', 'ArrowFunctionExpression'].includes(p.value.type)) value[name] = run(p.value);
        }
        return value;
      }
      case 'ArrayExpression': return n.elements.map(run);
      case 'CallExpression': return api(n.callee.property.name, n.arguments.map(run));
      case 'BinaryExpression':
        left = run(n.left); right = run(n.right);
        ensure((left === null || ['number', 'string', 'boolean'].includes(typeof left)) && (right === null || ['number', 'string', 'boolean'].includes(typeof right)), 'Operators require primitive values.');
        switch (n.operator) {
          case '+': { const v = left + right; ensure(typeof v !== 'string' || v.length <= 4096, 'Text is too long.'); return v; }
          case '-': return left - right; case '*': return left * right; case '/': return left / right; case '%': return left % right;
          case '===': return left === right; case '!==': return left !== right;
          case '<': return left < right; case '<=': return left <= right; case '>': return left > right; case '>=': return left >= right;
        }
        break;
      case 'LogicalExpression':
        left = run(n.left);
        return (n.operator === '&&' ? !!left : n.operator === '||' ? !left : left == null) ? run(n.right) : left;
      case 'UnaryExpression':
        left = run(n.argument); ensure(left === null || ['number', 'string', 'boolean'].includes(typeof left), 'Unary operators require primitive values.');
        return n.operator === '!' ? !left : n.operator === '+' ? +left : -left;
      case 'ConditionalExpression': return run(n.test) ? run(n.consequent) : run(n.alternate);
      case 'BlockStatement': for (const item of n.body) if (run(item) === returned) return returned; break;
      case 'ExpressionStatement': run(n.expression); break;
      case 'VariableDeclaration': for (const d of n.declarations) { ensure(!locals.has(d.id.name), 'Duplicate local variable.'); locals.set(d.id.name, run(d.init)); } break;
      case 'IfStatement': return run(n.test) ? run(n.consequent) : n.alternate ? run(n.alternate) : undefined;
      case 'ReturnStatement': if (n.argument) run(n.argument); return returned;
    }
  }
  const result = run(root);
  return hook ? undefined : jsonCopy(result);
}
export function compile(source, filename = 'addon.js') {
  ensure(typeof filename === 'string' && filename.length <= 256 && /\.(js|txt)$/i.test(filename), 'Choose a .js or .txt JavaScript file.');
  ensure(typeof source === 'string' && source.length > 0 && source.length <= LIMITS.source && utf8Size(source) <= LIMITS.source, 'JavaScript file is empty or too large (64 KiB limit).');
  let ast;
  try { ast = parse(source.replace(/^\uFEFF/, ''), { ecmaVersion: 2022, sourceType: 'module' }); }
  catch { throw new Error('Malformed JavaScript. Check the file syntax.'); }
  ensure(ast.body.length === 1 && ast.body[0].type === 'ExportDefaultDeclaration' && ast.body[0].declaration.type === 'ObjectExpression', 'Export one default addon object. Node.js scripts must be ported to the sandbox API.');
  const root = ast.body[0].declaration;
  validate(root);
  const names = root.properties.map(p => p.key.name ?? p.key.value);
  ensure(new Set(names).size === names.length, 'Duplicate addon properties.');
  return { manifest: evaluate(root), invoke(name, api) {
    const property = root.properties.find(p => (p.key.name ?? p.key.value) === name);
    if (property) { ensure(hooks.has(name) && ['FunctionExpression', 'ArrowFunctionExpression'].includes(property.value.type), 'Invalid lifecycle hook.'); evaluate(property.value.body, api, true); }
  }, hasHooks: names.some(n => hooks.has(n)) };
}
