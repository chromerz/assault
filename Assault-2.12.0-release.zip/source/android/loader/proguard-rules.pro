# Xposed loads the entry point by the name in assets/xposed_init.
-keep class app.assault.loader.AssaultLoader { *; }
-keepclassmembers class * extends de.robv.android.xposed.XC_MethodHook { protected *; }
# The host's Xposed runtime supplies the compile-only API.
-dontwarn de.robv.android.xposed.**
