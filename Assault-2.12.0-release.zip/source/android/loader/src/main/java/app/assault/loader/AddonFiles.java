package app.assault.loader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Publishes complete bridge responses on API 28 as well as newer Android. */
final class AddonFiles {
    static void publish(File target, byte[] bytes) throws IOException {
        File pending = new File(target.getParentFile(), ".pending-" + target.getName());
        try {
            try (FileOutputStream out = new FileOutputStream(pending)) {
                out.write(bytes);
                out.getFD().sync();
            }
            // Both files are in the same private cache directory. The JS reader
            // sees the final name only after all bytes have been flushed/closed.
            if (!pending.renameTo(target)) throw new IOException("Could not publish the addon result.");
        } finally { pending.delete(); }
    }
}
