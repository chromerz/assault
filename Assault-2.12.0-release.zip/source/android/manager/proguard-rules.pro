# apkzlib ships generated AutoValue implementations; these source annotations
# are not required at runtime.
-dontwarn com.google.auto.value.AutoValue
-dontwarn com.google.auto.value.AutoValue$Builder
# These field names are a JSON protocol consumed by the separately embedded DEX.
-keep class org.lsposed.lspatch.share.PatchConfig { *; }
-keep class org.lsposed.lspatch.share.LSPConfig { *; }
