import { settingsValues } from '../utils/validation.js';

function luminance(hex) {
  const rgb = hex.slice(1).match(/../g).map(value => {
    const channel = parseInt(value, 16) / 255;
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  });
  return rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722;
}

export function readableColor(background, preferred = '#ffffff') {
  const light = luminance(background), foreground = luminance(preferred);
  const contrast = (Math.max(light, foreground) + 0.05) / (Math.min(light, foreground) + 0.05);
  if (contrast >= 4.5) return preferred;
  return light > 0.179 ? '#000000' : '#ffffff';
}

export function settingsDraft(schema, draft) {
  const values = {}, errors = {};
  for (const [name, field] of Object.entries(schema)) {
    const raw = draft[name];
    const value = field.type === 'number' ? (String(raw).trim() === '' ? NaN : Number(raw)) : raw;
    try {
      values[name] = settingsValues({ [name]: field }, { [name]: value })[name];
    } catch {
      errors[name] = field.type === 'number'
        ? `Enter a number from ${field.min} to ${field.max}.`
        : field.type === 'string' ? 'Use no more than 512 characters.' : 'Choose on or off.';
    }
  }
  return { values, errors };
}
