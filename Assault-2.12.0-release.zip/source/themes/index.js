import { ensure } from '../utils/validation.js';
export const themeTokens = ['BACKGROUND_PRIMARY', 'BACKGROUND_SECONDARY', 'BACKGROUND_TERTIARY', 'TEXT_NORMAL', 'TEXT_MUTED', 'HEADER_PRIMARY', 'HEADER_SECONDARY', 'INTERACTIVE_NORMAL', 'INTERACTIVE_ACTIVE', 'BRAND_500'];
export function validateTheme(colors) {
  ensure(colors && typeof colors === 'object' && !Array.isArray(colors), 'A theme needs a colors object.');
  ensure(Object.keys(colors).length > 0, 'Theme colors are empty.');
  for (const [name, value] of Object.entries(colors)) ensure(themeTokens.includes(name) && typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value), `Invalid theme color: ${name}`);
  return colors;
}
export function nativeTheme(record) {
  if (!record) return null;
  return { name: record.manifest.name, spec: 2, semanticColors: Object.fromEntries(Object.entries(record.manifest.colors).filter(([k]) => k !== 'BRAND_500').map(([k, v]) => [k, [v, v, v]])), rawColors: record.manifest.colors.BRAND_500 ? { BRAND_500: record.manifest.colors.BRAND_500 } : {} };
}
