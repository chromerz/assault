import { build } from 'esbuild';
import { resolve } from 'node:path';
await build({ entryPoints: [resolve(import.meta.dirname, '../core/index.js')], bundle: true, platform: 'neutral', format: 'iife', target: 'es2020', outfile: process.argv[2] ?? resolve(import.meta.dirname, '../android/loader/src/main/assets/addons.js'), legalComments: 'eof' });
