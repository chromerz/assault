import { test } from 'node:test';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
test('native bridge publishes complete files and removes staging files after rename failure', () => {
  const dir = mkdtempSync(join(tmpdir(), 'assault-addon-files-'));
  try {
    const source = join(dir, 'AddonFilesTest.java');
    writeFileSync(source, `package app.assault.loader;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class AddonFilesTest {
 public static void main(String[] args)throws Exception {
  File target=new File(args[0],"assault-addon-result-test.json");byte[] data=new byte[4*1024*1024];Arrays.fill(data,(byte)42);
  java.util.concurrent.CompletableFuture<Void> writer=java.util.concurrent.CompletableFuture.runAsync(()->{try{AddonFiles.publish(target,data);}catch(Exception e){throw new RuntimeException(e);}});
  while(!writer.isDone()){if(target.exists()&&!Arrays.equals(Files.readAllBytes(target.toPath()),data))throw new AssertionError("partial result visible");Thread.yield();}
  writer.join();if(!Arrays.equals(Files.readAllBytes(target.toPath()),data))throw new AssertionError();
  File pending=new File(args[0],".pending-"+target.getName());if(pending.exists())throw new AssertionError();
  target.delete();target.mkdir();Files.write(new File(target,"occupied").toPath(),new byte[]{1});
  try{AddonFiles.publish(target,data);throw new AssertionError("rename should fail");}catch(IOException expected){}
  if(pending.exists()||!target.isDirectory())throw new AssertionError();
 }
}`);
    execFileSync('javac', ['-d', dir, resolve('android/loader/src/main/java/app/assault/loader/AddonFiles.java'), source]);
    execFileSync('java', ['-cp', dir, 'app.assault.loader.AddonFilesTest', dir]);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
