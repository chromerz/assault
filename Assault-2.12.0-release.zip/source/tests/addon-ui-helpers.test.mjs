import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readableColor, settingsDraft } from '../core/ui.js';

test('bright and dark control surfaces choose readable foregrounds', () => {
  assert.equal(readableColor('#ffffff'), '#000000');
  assert.equal(readableColor('#000000', '#000000'), '#ffffff');
  assert.equal(readableColor('#ffff00', '#ffffff'), '#000000');
  assert.equal(readableColor('#5865f2'), '#ffffff');
});

test('draft validation rejects empty, nonfinite and out-of-range numbers without losing valid fields', () => {
  const schema = { value: { type: 'number', min: -2, max: 5 }, label: { type: 'string' } };
  for (const value of ['', ' ', 'Infinity', 'NaN', '6', '-3']) {
    const checked = settingsDraft(schema, { value, label: 'kept' });
    assert.ok(checked.errors.value);
    assert.equal(checked.values.label, 'kept');
  }
  assert.deepEqual(settingsDraft(schema, { value: '-1.5', label: 'valid' }), { values: { value: -1.5, label: 'valid' }, errors: {} });
});
